﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace courseworkv5.Models
{
    public class WorkersBrigadesViewModel
    {
        public List<Workers> Workers = new List<Workers>();
        public string Brigade { get; set; }

    }
}